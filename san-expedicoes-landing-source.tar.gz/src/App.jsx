import React, { useState } from 'react';
import './App.css';
import { Button } from './components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Phone, MapPin, Star, Instagram, MessageCircle, Users, Calendar, Car, Waves, Moon, Utensils, Camera, Clock, Shield, Award, Mail } from 'lucide-react';
import { motion } from 'framer-motion';

// Importando as imagens
import lencois1 from './assets/lencois1.jpg';
import lencois2 from './assets/lencois2.jpg';
import lencois3 from './assets/lencois3.jpg';
import logoSanExpedicoes from './assets/logo-san-expedicoes.png';
import iconQuadriciclo from './assets/icon-quadriciclo.png';
import icon4x4 from './assets/icon-4x4.png';
import iconCavalgada from './assets/icon-cavalgada.jpg';
import iconPiquenique from './assets/icon-piquenique.png';
import iconTrekking from './assets/icon-trekking.png';

// Imagens da Galeria
import gallery1 from './assets/gallery1.jpg';
import gallery2 from './assets/gallery2.jpg';
import gallery3 from './assets/gallery3.jpg';
import gallery4 from './assets/gallery4.jpg';
import gallery5 from './assets/gallery5.jpg';
import gallery6 from './assets/gallery6.jpg';
import gallery7 from './assets/gallery7.jpg';
import gallery8 from './assets/gallery8.jpg';
import gallery9 from './assets/gallery9.jpg';
import gallery10 from './assets/gallery10.jpg';
import gallery11 from './assets/gallery11.jpg';

function App() {
  const [activeTab, setActiveTab] = useState("principais");

  // Serviços organizados por categoria
  const servicosPrincipais = [
    {
      title: "Quadriciclos",
      description: "Aventure-se pelas dunas dos Lençóis Maranhenses em quadriciclos potentes e seguros.",
      details: "Saindo de Atins e Santo Amaro (Privativo)",
      icon: iconQuadriciclo,
      price: "Consulte valores",
      category: "Aventura"
    },
    {
      title: "Carro 4x4",
      description: "Explore os Lençóis com conforto e segurança em nossos veículos 4x4.",
      details: "Saindo de Atins e Santo Amaro (Privativo)",
      icon: icon4x4,
      price: "Consulte valores",
      category: "Aventura"
    },
    {
      title: "Cavalgada",
      description: "Viva uma experiência única cavalgando pelas paisagens deslumbrantes.",
      details: "Saindo de Atins (Privativo)",
      icon: iconCavalgada,
      price: "Consulte valores",
      category: "Aventura"
    }
  ];

  const experienciasEspeciais = [
    {
      title: "Travessia",
      description: "Expedição completa pelos Lençóis Maranhenses com pernoite.",
      details: "A partir de 3 noites (Privativo)",
      icon: <Calendar className="w-8 h-8" />,
      price: "Consulte valores",
      category: "Expedição"
    },
    {
      title: "Piquenique nos Lençóis",
      description: "Desfrute de um piquenique exclusivo em meio às lagoas cristalinas.",
      details: "Experiência gastronômica única (Privativo)",
      icon: iconPiquenique,
      price: "Consulte valores",
      category: "Gastronomia"
    },
    {
      title: "Luau nos Lençóis",
      description: "Noite mágica com fogueira e música em cenário paradisíaco.",
      details: "Experiência noturna inesquecível (Privativo)",
      icon: <Moon className="w-8 h-8" />,
      price: "Consulte valores",
      category: "Noturno"
    },
    {
      title: "Plânctons e Estrelas",
      description: "Observe plânctons luminosos e contemple o céu estrelado.",
      details: "Experiência noturna única (Privativo)",
      icon: <Star className="w-8 h-8" />,
      price: "Consulte valores",
      category: "Noturno"
    }
  ];

  const servicosPersonalizados = [
    {
      title: "Experiências em Grupos",
      description: "Aventuras personalizadas para grupos de amigos ou família.",
      details: "Roteiros exclusivos (Privativo)",
      icon: <Users className="w-8 h-8" />,
      price: "Consulte valores",
      category: "Grupo"
    },
    {
      title: "Pacotes Personalizados",
      description: "Crie sua própria aventura com roteiros sob medida.",
      details: "Totalmente customizável (Privativo)",
      icon: <Camera className="w-8 h-8" />,
      price: "Consulte valores",
      category: "Personalizado"
    },
    {
      title: "Eventos Fechados",
      description: "Celebrações especiais em cenários únicos dos Lençóis.",
      details: "Casamentos, aniversários e corporativo (Privativo)",
      icon: <Award className="w-8 h-8" />,
      price: "Consulte valores",
      category: "Evento"
    },
    {
      title: "Transfer",
      description: "Transporte confortável e seguro para seus destinos.",
      details: "Aeroporto, hotéis e pontos turísticos (Privativo)",
      icon: <Car className="w-8 h-8" />,
      price: "Consulte valores",
      category: "Transporte"
    }
  ];

  const servicoCompartilhado = {
    title: "Passeios Compartilhados",
    description: "Opção econômica para conhecer os Lençóis Maranhenses.",
    details: "Verificar disponibilidade",
    icon: <Users className="w-8 h-8" />,
    price: "Valores reduzidos",
    category: "Econômico"
  };

  const galleryImages = [
    gallery1, gallery2, gallery3, gallery4, gallery5, gallery6, 
    gallery7, gallery8, gallery9, gallery10, gallery11
  ];

  const whatsappNumber = "5598991961572";
  const whatsappNumber2 = "5598996134307";
  const emailAddress = "sanexpedicoes@gmail.com";
  const whatsappMessage = "Olá! Gostaria de saber mais sobre os passeios da San Expedições nos Lençóis Maranhenses.";

  const handleWhatsAppClick = (number = whatsappNumber) => {
    const url = `https://wa.me/${number}?text=${encodeURIComponent(whatsappMessage)}`;
    window.open(url, '_blank');
  };

  const handleInstagramClick = () => {
    window.open('https://www.instagram.com/sanexpedicoes?igsh=MWx4ZGd0OXo2ZTQ0&utm_source=qr', '_blank');
  };

  const handleEmailClick = () => {
    window.location.href = `mailto:${emailAddress}`;
  };

  const ServiceCard = ({ service, index }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
    >
      <Card className="h-full hover:shadow-xl transition-all duration-300 border-0 shadow-lg group hover:scale-105">
        <CardHeader className="text-center pb-4">
          <div className="mx-auto mb-4 w-16 h-16 bg-gradient-to-br from-blue-100 to-orange-100 rounded-full flex items-center justify-center group-hover:from-blue-200 group-hover:to-orange-200 transition-all duration-300">
            {typeof service.icon === 'string' ? (
              <img 
                src={service.icon} 
                alt={service.title}
                className="w-10 h-10 object-contain"
              />
            ) : (
              <div className="text-blue-600">{service.icon}</div>
            )}
          </div>
          <CardTitle className="text-xl text-blue-900 mb-2">{service.title}</CardTitle>
          <Badge variant="secondary" className="bg-orange-100 text-orange-800 w-fit mx-auto mb-2">
            {service.category}
          </Badge>
          <Badge variant="outline" className="border-blue-200 text-blue-700 w-fit mx-auto">
            {service.price}
          </Badge>
        </CardHeader>
        <CardContent className="text-center">
          <CardDescription className="text-gray-600 mb-4 leading-relaxed">
            {service.description}
          </CardDescription>
          <p className="text-sm text-blue-600 font-medium mb-6">
            {service.details}
          </p>
          <Button 
            onClick={() => handleWhatsAppClick(whatsappNumber)}
            className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white"
          >
            <MessageCircle size={16} className="mr-2" />
            Solicitar Orçamento
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-sm shadow-lg sticky top-0 z-50 border-b border-blue-100">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center space-x-3"
          >
            <img 
              src={logoSanExpedicoes} 
              alt="San Expedições" 
              className="h-12 w-12 object-contain"
            />
            <div>
              <h1 className="text-2xl font-bold text-blue-900">San Expedições</h1>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800 text-xs">
                Atins - Lençóis Maranhenses
              </Badge>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center space-x-4"
          >
            <Button
              variant="outline"
              onClick={handleInstagramClick}
              className="border-blue-200 text-blue-600 hover:bg-blue-50"
            >
              <Instagram size={16} className="mr-2" />
              Instagram
            </Button>
            <Button 
              onClick={() => handleWhatsAppClick(whatsappNumber)}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <MessageCircle size={16} className="mr-2" />
              WhatsApp
            </Button>
          </motion.div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${lencois1})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-black/50"></div>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 text-center text-white px-4 max-w-5xl mx-auto"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            className="mb-8"
          >
            <img 
              src={logoSanExpedicoes} 
              alt="San Expedições" 
              className="h-24 w-24 mx-auto mb-4 drop-shadow-2xl"
            />
          </motion.div>
          
          <h2 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Descubra os
            <span className="block bg-gradient-to-r from-blue-300 to-orange-300 bg-clip-text text-transparent">
              Lençóis Maranhenses
            </span>
          </h2>
          <p className="text-xl md:text-2xl mb-8 max-w-4xl mx-auto leading-relaxed">
            Viva aventuras inesquecíveis em Atins com a San Expedições. 
            Explore as dunas, lagoas cristalinas e paisagens únicas do paraíso maranhense 
            com experiências exclusivas e personalizadas.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => handleWhatsAppClick(whatsappNumber)}
              className="bg-green-600 hover:bg-green-700 text-white text-lg px-8 py-4 shadow-xl"
            >
              <MessageCircle size={20} className="mr-2" />
              Fale Conosco
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="bg-white/10 border-white text-white hover:bg-white hover:text-blue-900 text-lg px-8 py-4 backdrop-blur-sm"
              onClick={() => document.getElementById('services').scrollIntoView({ behavior: 'smooth' })}
            >
              Ver Experiências
            </Button>
          </div>
        </motion.div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h3 className="text-4xl font-bold text-blue-900 mb-6">
              Sua Aventura nos Lençóis Maranhenses
            </h3>
            <p className="text-lg text-gray-600 max-w-4xl mx-auto leading-relaxed">
              A San Expedições é especializada em proporcionar experiências únicas e seguras 
              nos Lençóis Maranhenses. Com guias experientes, equipamentos de qualidade e 
              atendimento personalizado, garantimos que sua aventura seja inesquecível.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div className="flex items-center space-x-4">
                <div className="bg-gradient-to-br from-blue-100 to-orange-100 p-4 rounded-full">
                  <MapPin className="text-blue-600" size={28} />
                </div>
                <div>
                  <h4 className="font-semibold text-xl text-blue-900">Localização Privilegiada</h4>
                  <p className="text-gray-600">Baseados em Atins, porta de entrada dos Lençóis</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="bg-gradient-to-br from-blue-100 to-orange-100 p-4 rounded-full">
                  <Shield className="text-blue-600" size={28} />
                </div>
                <div>
                  <h4 className="font-semibold text-xl text-blue-900">Segurança Garantida</h4>
                  <p className="text-gray-600">Equipamentos certificados e guias experientes</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="bg-gradient-to-br from-blue-100 to-orange-100 p-4 rounded-full">
                  <Award className="text-blue-600" size={28} />
                </div>
                <div>
                  <h4 className="font-semibold text-xl text-blue-900">Experiência Comprovada</h4>
                  <p className="text-gray-600">Anos de experiência em turismo de aventura</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="bg-gradient-to-br from-blue-100 to-orange-100 p-4 rounded-full">
                  <Clock className="text-blue-600" size={28} />
                </div>
                <div>
                  <h4 className="font-semibold text-xl text-blue-900">Atendimento 24h</h4>
                  <p className="text-gray-600">Suporte completo antes, durante e após o passeio</p>
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="grid grid-cols-2 gap-4"
            >
              <img 
                src={lencois2} 
                alt="Lençóis Maranhenses" 
                className="rounded-lg shadow-lg h-48 w-full object-cover hover:scale-105 transition-transform duration-300"
              />
              <img 
                src={lencois3} 
                alt="Lençóis Maranhenses" 
                className="rounded-lg shadow-lg h-48 w-full object-cover mt-8 hover:scale-105 transition-transform duration-300"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="container mx-auto px-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h3 className="text-4xl font-bold text-blue-900 mb-6">
              Nossas Experiências
            </h3>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto mb-8">
              Escolha entre nossas opções de aventura e descubra os Lençóis Maranhenses 
              da forma que mais combina com você. Todos os nossos serviços são privativos 
              para garantir uma experiência exclusiva.
            </p>
          </motion.div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-12 bg-white shadow-lg rounded-lg p-2">
              <TabsTrigger 
                value="principais" 
                className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
              >
                Aventuras Principais
              </TabsTrigger>
              <TabsTrigger 
                value="especiais"
                className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
              >
                Experiências Especiais
              </TabsTrigger>
              <TabsTrigger 
                value="personalizados"
                className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
              >
                Serviços Personalizados
              </TabsTrigger>
              <TabsTrigger 
                value="compartilhado"
                className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
              >
                Opção Econômica
              </TabsTrigger>
            </TabsList>

            <TabsContent value="principais">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {servicosPrincipais.map((service, index) => (
                  <ServiceCard key={index} service={service} index={index} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="especiais">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {experienciasEspeciais.map((service, index) => (
                  <ServiceCard key={index} service={service} index={index} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="personalizados">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {servicosPersonalizados.map((service, index) => (
                  <ServiceCard key={index} service={service} index={index} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="compartilhado">
              <div className="flex justify-center">
                <div className="max-w-md">
                  <ServiceCard service={servicoCompartilhado} index={0} />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 bg-blue-50">
        <div className="container mx-auto px-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h3 className="text-4xl font-bold text-blue-900 mb-6">
              Galeria de Momentos
            </h3>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Inspire-se com a beleza dos Lençóis Maranhenses e as aventuras que esperam por você.
            </p>
          </motion.div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {galleryImages.map((image, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="overflow-hidden rounded-lg shadow-lg aspect-video"
              >
                <img 
                  src={image} 
                  alt={`Galeria ${index + 1}`}
                  className="w-full h-full object-cover transform hover:scale-110 transition-transform duration-300"
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h3 className="text-4xl font-bold mb-6">
              Pronto para Sua Aventura?
            </h3>
            <p className="text-xl mb-8 max-w-3xl mx-auto leading-relaxed">
              Entre em contato conosco e planeje sua experiência única nos Lençóis Maranhenses. 
              Oferecemos atendimento personalizado e orçamentos sob medida para tornar sua viagem inesquecível!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => handleWhatsAppClick(whatsappNumber)}
                className="bg-green-600 hover:bg-green-700 text-white text-lg px-8 py-4 shadow-xl"
              >
                <MessageCircle size={20} className="mr-2" />
                Falar no WhatsApp
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-blue-900 text-lg px-8 py-4"
                onClick={handleInstagramClick}
              >
                <Instagram size={20} className="mr-2" />
                Seguir no Instagram
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <img 
                  src={logoSanExpedicoes} 
                  alt="San Expedições" 
                  className="h-12 w-12 object-contain"
                />
                <h4 className="text-xl font-bold">San Expedições</h4>
              </div>
              <p className="text-gray-400 leading-relaxed mb-4">
                Sua agência de turismo especializada em aventuras nos Lençóis Maranhenses, 
                oferecendo experiências únicas, seguras e personalizadas em Atins.
              </p>
              <div className="flex space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleInstagramClick}
                  className="border-gray-600 text-gray-300 hover:bg-gray-800"
                >
                  <Instagram size={16} className="mr-2" />
                  @sanexpedicoes
                </Button>
                <Button
                  size="sm"
                  onClick={() => handleWhatsAppClick(whatsappNumber)}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <MessageCircle size={16} className="mr-2" />
                  WhatsApp
                </Button>
              </div>
            </div>
            
            <div>
              <h4 className="text-xl font-bold mb-4">Contato</h4>
              <div className="space-y-3 text-gray-400">
                <p className="flex items-center">
                  <MapPin size={16} className="mr-2 text-blue-400" />
                  Atins, Barreirinhas - MA
                </p>
                <p className="flex items-center">
                  <Phone size={16} className="mr-2 text-blue-400" />
                  (98) 99196-1572
                </p>
                <p className="flex items-center">
                  <Phone size={16} className="mr-2 text-blue-400" />
                  (98) 99613-4307
                </p>
                <p className="flex items-center">
                  <Mail size={16} className="mr-2 text-blue-400" />
                  {emailAddress}
                </p>
                <p className="flex items-center">
                  <Instagram size={16} className="mr-2 text-blue-400" />
                  @sanexpedicoes
                </p>
              </div>
            </div>
            
            <div>
              <h4 className="text-xl font-bold mb-4">Experiências</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Quadriciclos e 4x4</li>
                <li>Cavalgadas</li>
                <li>Travessias</li>
                <li>Piqueniques e Luaus</li>
                <li>Plânctons e Estrelas</li>
                <li>Pacotes Personalizados</li>
                <li>Eventos Fechados</li>
                <li>Transfer</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 San Expedições. Todos os direitos reservados.</p>
            <p className="mt-2 text-sm">Desenvolvido com ❤️ para proporcionar as melhores aventuras nos Lençóis Maranhenses</p>
          </div>
        </div>
      </footer>

      {/* WhatsApp Floating Button */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 1, type: "spring", stiffness: 260, damping: 20 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <Button
          onClick={() => handleWhatsAppClick(whatsappNumber)}
          className="bg-green-500 hover:bg-green-600 text-white rounded-full w-16 h-16 shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-110"
          size="icon"
        >
          <MessageCircle size={28} />
        </Button>
      </motion.div>
    </div>
  );
}

export default App;

